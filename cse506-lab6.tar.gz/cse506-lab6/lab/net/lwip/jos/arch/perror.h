#ifndef JOS_INC_PERROR_H
#define JOS_INC_PERROR_H

void perror(const char *s);
const char *e2s(int e);

#endif /* !JOS_INC_PERROR_H */
